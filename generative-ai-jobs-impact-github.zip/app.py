import pandas as pd
import plotly.express as px
import streamlit as st
from pathlib import Path

st.set_page_config(page_title="Generative AI & Jobs", page_icon="🤖", layout="wide")

DATA_PATH = Path(__file__).parent / "data" / "occupations.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH)
    return df

df = load_data()

st.title("🤖 Generative AI & the Future of Jobs")
st.caption("An interactive exploratory study of task exposure, augmentation potential, and human judgment.")
st.info(
    "Important: The occupation scores in this demo are illustrative, author-created values—not measured labor-market "
    "statistics or predictions. Use them to explore the framework, not to rank real careers definitively."
)

with st.sidebar:
    st.header("Explore the dataset")
    sectors = sorted(df["sector"].unique())
    selected_sectors = st.multiselect("Sectors", sectors, default=sectors)
    metric = st.selectbox(
        "Color chart by",
        ["task_exposure_pct", "augmentation_potential_pct", "human_judgment_importance_pct"],
        format_func=lambda x: {
            "task_exposure_pct": "Task exposure (illustrative)",
            "augmentation_potential_pct": "Augmentation potential (illustrative)",
            "human_judgment_importance_pct": "Human judgment importance (illustrative)",
        }[x],
    )
    search = st.text_input("Find an occupation", placeholder="e.g., data analyst")

filtered = df[df["sector"].isin(selected_sectors)].copy()
if search.strip():
    filtered = filtered[filtered["occupation"].str.contains(search.strip(), case=False, na=False)]

c1, c2, c3 = st.columns(3)
c1.metric("Occupations in view", len(filtered))
c2.metric("Sectors in view", filtered["sector"].nunique())
c3.metric("Average task-exposure score", f"{filtered['task_exposure_pct'].mean():.0f}/100" if len(filtered) else "—")

st.subheader("How do occupations compare?")
if filtered.empty:
    st.warning("No occupations match these filters. Try another sector or search term.")
else:
    chart = px.scatter(
        filtered,
        x="task_exposure_pct",
        y="augmentation_potential_pct",
        size="human_judgment_importance_pct",
        color=metric,
        hover_name="occupation",
        hover_data={"sector": True, "task_exposure_pct": True,
                    "augmentation_potential_pct": True,
                    "human_judgment_importance_pct": True, metric: False},
        labels={
            "task_exposure_pct": "Task exposure score (illustrative)",
            "augmentation_potential_pct": "Augmentation potential score (illustrative)",
            "human_judgment_importance_pct": "Human judgment importance",
            metric: metric.replace("_", " ").title(),
        },
        title="Task exposure vs. augmentation potential",
    )
    chart.update_layout(height=520)
    st.plotly_chart(chart, use_container_width=True)

    left, right = st.columns(2)
    with left:
        st.subheader("Average scores by sector")
        sector_avg = filtered.groupby("sector", as_index=False)[
            ["task_exposure_pct", "augmentation_potential_pct", "human_judgment_importance_pct"]
        ].mean().round(1)
        melted = sector_avg.melt(id_vars="sector", var_name="measure", value_name="score")
        melted["measure"] = melted["measure"].map({
            "task_exposure_pct": "Task exposure",
            "augmentation_potential_pct": "Augmentation potential",
            "human_judgment_importance_pct": "Human judgment",
        })
        bar = px.bar(melted, x="sector", y="score", color="measure", barmode="group",
                     labels={"sector": "Sector", "score": "Illustrative score", "measure": "Measure"})
        bar.update_layout(height=430, xaxis_tickangle=-25)
        st.plotly_chart(bar, use_container_width=True)
    with right:
        st.subheader("Occupation details")
        st.dataframe(
            filtered[["occupation", "sector", "task_exposure_pct",
                      "augmentation_potential_pct", "human_judgment_importance_pct", "notes"]],
            use_container_width=True, hide_index=True
        )

st.divider()
st.subheader("What the scores mean")
st.markdown("""
- **Task exposure:** how much of an occupation's task mix might be affected by generative AI tools in this illustrative example.
- **Augmentation potential:** how much AI might assist a person doing the work, rather than replace the whole role.
- **Human judgment importance:** how much the example assumes the role depends on context, accountability, relationships, or physical-world judgment.

These are separate concepts. A job can have high task exposure and high augmentation potential at the same time.
The unit of analysis should be **tasks**, not job titles: most occupations contain a mix of automatable, assistable, and
human-centered activities.
""")

st.subheader("Study questions")
st.markdown("""
1. Which sectors show high potential for AI assistance in this illustrative dataset?
2. Why does high task exposure not automatically mean a job will disappear?
3. What skills could help workers adapt (AI literacy, domain expertise, critical thinking, communication, and verification)?
4. What safeguards are needed for privacy, bias, reliability, and accountability?
""")

st.caption("Project type: educational data-analysis demo • Built with Python, pandas, Streamlit, and Plotly.")
