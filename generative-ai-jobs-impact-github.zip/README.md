# Generative AI Impact on Jobs — Interactive Study

An open-source, beginner-friendly data-analysis project exploring how generative AI may affect work tasks, support workers, and change skill requirements.

## Project overview

This project provides an interactive Streamlit dashboard to compare occupations across three dimensions:

- **Task exposure** — an illustrative estimate of how much a task mix could be affected by generative AI.
- **Augmentation potential** — an illustrative estimate of how much AI could assist a worker.
- **Human judgment importance** — an illustrative estimate of how much contextual judgment, accountability, relationships, or physical-world work matters.

The dashboard includes filters, a scatter plot, sector comparisons, and an occupation-level table.

> **Data transparency:** `data/occupations.csv` is a hand-created illustrative dataset for demonstrating data analysis and visualization. Its scores are not official statistics, research findings, or forecasts. Do not use them to make career, hiring, or policy decisions.

## Screenshots

Run the app locally and capture a screenshot to add here, if desired.

## Tech stack

- Python
- pandas
- Streamlit
- Plotly

## Run locally

1. Install Python 3.10 or later.
2. Clone this repository:

   ```bash
   git clone https://github.com/YOUR-USERNAME/generative-ai-jobs-impact.git
   cd generative-ai-jobs-impact
   ```

3. (Recommended) Create and activate a virtual environment:

   **Windows**
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies and launch:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

The app should open in your browser.

## Repository structure

```text
generative-ai-jobs-impact/
├── app.py
├── data/
│   └── occupations.csv
├── requirements.txt
├── README.md
├── LICENSE
└── .gitignore
```

## Research context and recommended sources

To turn this demo into a research-grade project, replace the illustrative scores with clearly sourced data and document the methodology. These are useful starting points for the research question—not sources for the demo scores:

- **International Labour Organization (ILO), 2025:** research on generative AI and jobs, including potential exposure and job transformation. https://www.ilo.org/
- **OECD Employment Outlook:** research on AI, work, skills, and employment. https://www.oecd.org/employment-outlook/
- **World Economic Forum, Future of Jobs Report:** employer expectations about skills and labor-market change. https://www.weforum.org/reports/
- **U.S. Bureau of Labor Statistics, Occupational Outlook Handbook:** occupation descriptions and employment projections. https://www.bls.gov/ooh/
- **O*NET OnLine:** occupation and task descriptions useful for task-level analysis. https://www.onetonline.org/

Check each source's latest publication, methodology, geography, and license before using its figures. Do not combine estimates from different sources without explaining their definitions.

## Suggested research methodology

1. Choose a specific question, such as: *Which types of tasks are most likely to be transformed by generative AI?*
2. Collect data from named, credible sources and record publication year, geography, units, and URL.
3. Define how each score is calculated; keep exposure, automation, and augmentation separate.
4. Add citations and a `data_sources.md` file.
5. Compare results across sectors and discuss uncertainty, limitations, and distributional effects.
6. Avoid claiming that a high exposure score means a job will be eliminated. Adoption depends on costs, regulation, workflow redesign, worker skills, and demand.

## Limitations

- The included values are illustrative, not empirical.
- Occupation-level averages can hide substantial variation between tasks and workplaces.
- The project does not predict job losses, wages, or employment growth.
- AI impacts differ by country, industry, organization, and time horizon.

## Future improvements

- Replace demo data with sourced task-level datasets.
- Add country and year filters.
- Add a transparent scoring method and source links per occupation.
- Include worker survey results and uncertainty intervals.
- Add tests for data validation and deploy the app with Streamlit Community Cloud.

## License

Released under the MIT License. See `LICENSE`.
